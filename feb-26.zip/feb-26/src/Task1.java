import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) throws InterruptedException {
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		//02-02-2004
		int digit=0;
		//to get the sum of all numbers
		
		int sum=0;
		do
		{
		sum=0;
			
			///sum of all the digits
			for(char c:str.toCharArray())
			{
				if(Character.isDigit(c))
					sum+=(c-48);		//c is a char. if you do arithmetic, its ascii value 
			}
//			System.out.println("the sum of digits is "+sum);
			
			str=sum+"";
			
		}while(str.length()>1);
		if(sum==1)
			System.out.println("Magic date");
		else
			System.out.println("No magic date");
	}

}
