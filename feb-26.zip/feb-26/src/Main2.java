import java.util.TreeMap;
import java.util.Map.Entry;

public class Main2 {

	public static void main(String[] args) {
		TreeMap<String, String> cc=new TreeMap<>((a,b)->b.compareTo(a));
		cc.put("INR","Bharath");
		cc.put("USD","United States of America");
		cc.put("AED","United Arab Emirates Dirham");
		cc.put("AFN","Afghanistan Afghani");
		cc.put("ALL","Albania Lek");
		cc.put("AMD","Armenia Dram");
		for(Entry<String, String> entry:cc.entrySet())
		{
			System.out.println(entry.getKey()+"\t:\t"+entry.getValue());
		}
	}

}
