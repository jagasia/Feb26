import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class Main1 {

	public static void main(String[] args) {
		HashMap<String, String> cc=new HashMap<>();
		//there is no add method in map
		//use put and get
		cc.put("INR","Bharath");
		cc.put("USD","United States of America");
		cc.put("AED","United Arab Emirates Dirham");
		cc.put("AFN","Afghanistan Afghani");
		cc.put("ALL","Albania Lek");
		cc.put("AMD","Armenia Dram");
		//how to display Map???
		//i) get the keys as a set
//		Set<String> keys = cc.keySet();	
//		for(String key:keys)
//			System.out.println(key+"\t:\t"+cc.get(key));
//		
		//ii) using for each loop. Look the map is a Set of entries
		for(Entry<String, String> entry:cc.entrySet())
		{
			System.out.println(entry.getKey()+"\t:\t"+entry.getValue());
		}
	}
}
//		//before updating INR
//		System.out.println(cc.get("INR"));
//		cc.put("INR", "India");
//		//after updating IR
//		System.out.println(cc.get("INR"));
//		Scanner sc=new Scanner(System.in);
//		System.out.print("Enter the code:");
//		String code=sc.next();
//		System.out.format("In %s, they use %s\n",cc.get(code), code);
		
//	}

	
	
//}
