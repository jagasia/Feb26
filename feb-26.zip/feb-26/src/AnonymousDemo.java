
interface Person
{
	public void speak();
	public void listen();
}

public class AnonymousDemo {

	public static void main(String[] args) {
		Person rama=new Person() {
			
			@Override
			public void speak() {
				System.out.println("Person speaks");
				
			}
			
			@Override
			public void listen() {
				System.out.println("Person listens");
				
			}
		};
		rama.speak();
		rama.listen();
	}

}
