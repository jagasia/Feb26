import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class CharCount {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=sc.nextLine();
		Map<Character, Integer> result=new HashMap<Character, Integer>();
		for(int i=0;i<input.length();i++)
		{
			char key=input.charAt(i);
			if(key==' ')
				continue;
			Integer value = result.get(key);	//if found, get an Integer, else get null
			if(value==null)
				value=0;
			value++;
			result.put(key, value);
		}
		
		for(Entry<Character, Integer> entry:result.entrySet())
			System.out.println(entry.getKey()+"\t:\t"+entry.getValue());
	}

}
