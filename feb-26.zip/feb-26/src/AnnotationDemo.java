import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

public class AnnotationDemo {

	public static void main(String[] args) {
		
		Employee rama=new Employee();
//		rama.enroll();
//		rama.onBoard();
		
		//find all the methods present in EMployee class
		Method[] methods = Employee.class.getMethods();
		for(Method m:methods)
		{
			System.out.println(m.getName());
			Annotation[] ans = m.getAnnotations();
			for(Annotation an:ans)
			{
				System.out.println("......"+an.toString());
			}
		}
	}

}
