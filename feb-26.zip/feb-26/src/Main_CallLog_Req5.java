import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class Main_CallLog_Req5 {

	public static void main(String[] args) throws ParseException {
		List<Contact> contactList = Contact.prefill();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of calls:");
		int n=sc.nextInt();
		List<Call> callList=new ArrayList<Call>();
		SimpleDateFormat sdf1=new SimpleDateFormat("HH:mm:ss");
		SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
		for(int i=0;i<n;i++)
		{
			String detail=sc.nextLine();
			if(detail.equals(""))
				detail=sc.nextLine();
			String[] arr = detail.split(",");
			String type=arr[1];
			String callType=arr[2];
			Double cost=Double.valueOf(arr[3]);

			Date duration=sdf1.parse(arr[4]);

			Date date=sdf2.parse(arr[5]);
			Contact contact=null;
			String contactName = arr[0];
			//find Contact object using contact name from prefill contact List
			for(Contact c:contactList)
			{
				if(c.getName().equals(contactName))
					contact=c;
			}
			Call call=new Call(type, callType, cost, duration, date, contact);
			callList.add(call);
		}
		
		Map<String, Integer> result = Call.monthWiseCount(callList);
		System.out.printf("%-10s %s\n","Month", "Count"); 
		for(Entry<String, Integer> e:result.entrySet())
			System.out.printf("%-10s %s\n",e.getKey(), e.getValue()); 


	}
}
