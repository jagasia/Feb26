
public class Main4 {

	public static void main(String[] args) {
		System.out.format("%o ... %x",8,16);
	}
}
