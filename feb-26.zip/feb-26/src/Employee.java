import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class Employee {
	
	@Deprecated
	public void enroll()
	{
		System.out.println("Employee joining procedures start now...");
	}
	
	@Encouraged(message="THis method is encouraged to use")
	public void onBoard()
	{
		System.out.println("The procedures for on Board start now...");
	}

	@Override
	public String toString() {
		return "Employee []";
	}
	
}
