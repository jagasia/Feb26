import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AnonymousFunctionDemo {

	public static void main(String[] args) {
		List<Integer> marks=new ArrayList<Integer>();
		marks.add(12);
		marks.add(2);
		marks.add(22);
		marks.add(122);
		marks.add(212);
		marks.add(112);
		marks.add(152);
		marks.add(125);
		marks.add(512);
		marks.add(132);
		Collections.sort(marks,(a,b)->b.compareTo(a));
		for(Integer x:marks)
			System.out.println(x);
	}

}
