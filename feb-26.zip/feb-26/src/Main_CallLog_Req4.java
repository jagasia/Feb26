import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main_CallLog_Req4 {

	public static void main(String[] args) throws ParseException {
		List<Contact> contactList = Contact.prefill();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of calls:");
		int n=sc.nextInt();
		List<Call> callList=new ArrayList<Call>();
		SimpleDateFormat sdf1=new SimpleDateFormat("HH:mm:ss");
		SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
		for(int i=0;i<n;i++)
		{
			String detail=sc.nextLine();
			if(detail.equals(""))
				detail=sc.nextLine();
			String[] arr = detail.split(",");
			String type=arr[0];
			String callType=arr[1];
			Double cost=Double.valueOf(arr[2]);

			Date duration=sdf1.parse(arr[3]);

			Date date=sdf2.parse(arr[4]);
			Contact contact=null;
			String contactName = arr[5];
			//find Contact object using contact name from prefill contact List
			for(Contact c:contactList)
			{
				if(c.getName().equals(contactName))
					contact=c;
			}
			Call call=new Call(type, callType, cost, duration, date, contact);
			callList.add(call);
		}
		System.out.println("Enter a search type:\r\n" + 
				"1.By a name\r\n" + 
				"2.By a call date\r\n" + 
				"");
		int choice=sc.nextInt();
		CallBO cbo=new CallBO();
		List<Call> result=null;

		switch(choice)
		{
		case 1:
			System.out.println("Enter the name:");
			String name=sc.nextLine();
			if(name.equals(""))
				name=sc.nextLine();
			result = cbo.findCall(callList, name);
			if(result.size()==0)
			{
				System.out.println("No calls from "+name);
				System.exit(0);
			}
			break;
		case 2:
			System.out.println("Enter the call date:");
			String sdate=sc.nextLine();
			if(sdate.equals(""))
				sdate=sc.nextLine();
			Date dt = sdf2.parse(sdate);
			result=cbo.findCall(callList, dt);
			if(result.size()==0)
			{
				System.out.println("No calls on "+sdate);
				System.exit(0);
			}
			break;
		default:
			System.out.println("Invalid choice");
			System.exit(0);
		}
		System.out.format("%-13s %-15s %-10s %-10s %-10s %-15s %s\n","Name","Mobile Number","Type", "Call Type","Cost" ,"Duration","Date");
		for(Call c:result)
			System.out.format("%-13s %-15s %-10s %-10s %-10s %-15s %s\n",c.getContact().getName(),c.getContact().getMobileNumber(),c.getType(), c.getCallType(),c.getCost() ,sdf1.format(c.getDuration()),sdf2.format(c.getDate()));




	}
}
