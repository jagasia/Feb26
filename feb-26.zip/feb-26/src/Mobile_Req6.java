import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class Mobile_Req6 {

	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of mobiles");
		int n=sc.nextInt();
		List<Mobile> mobileList=new ArrayList<Mobile>();
		for(int i=0;i<n;i++)
		{
			String detail=sc.nextLine();
			if(detail.equals(""))
				detail=sc.nextLine();
			Mobile mobile=Mobile.createMobile(detail);
			mobileList.add(mobile);
		}
		Map<Integer, Integer> result = Mobile.yearWiseCount(mobileList);
		System.out.format("%-15s %s\n","Year","No. of Mobiles");
		for(Entry<Integer, Integer> entry:result.entrySet())
			System.out.format("%-15s %s\n",entry.getKey(),entry.getValue());
	}

}
