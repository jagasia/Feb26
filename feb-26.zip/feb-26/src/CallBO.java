import java.util.ArrayList;
import java.util.List;

public class CallBO {
	public List<Call> findCall(List<Call> callList,java.util.Date date)
	{
		List<Call> result=new ArrayList<Call>();
		for(Call call:callList)
		{
			if(call.getDate().equals(date))
			{
				result.add(call);
			}
		}
		return result;
	}
	public List<Call> findCall(List<Call> callList,String contactName)
	{
		List<Call> result=new ArrayList<Call>();
		for(Call call:callList)
		{
			if(call.getContact().getName().equalsIgnoreCase(contactName))
			{
				result.add(call);
			}
		}
		return result;
	}
}
