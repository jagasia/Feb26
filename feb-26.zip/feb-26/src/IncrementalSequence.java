import java.util.Scanner;

public class IncrementalSequence {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		int index=0;
		char[] carr = str.toCharArray();
		int previous=carr[0]-48;
		int violation=0;
		boolean isValid=true;
		int digitSum=previous;
		for(int i=1;i<carr.length;i++)
		{
			int current=carr[i]-48;
//			System.out.println("Comparing "+previous+" with "+current);
			if(previous>current)
			{
				violation=previous;
				isValid=false;
			}
			digitSum+=current;
			previous=current;
		}
		
		if(!isValid) {
			System.out.println("False");
			System.out.println(violation);
		}else
		{
			System.out.println("True");
			System.out.println(digitSum);
		}

	}

}
