import java.util.StringJoiner;

public class StringJoinerDemo {

	public static void main(String[] args) {
		StringJoiner sj=new StringJoiner(",");
		sj.add("India");
		sj.add("Australia");
		sj.add("Pakistan");
		sj.add("Sri lanka");
		sj.add("Canada");
		sj.add("Japan");
		sj.add("China");
		sj.add("Bangladesh");
		System.out.println(sj);
	}

}
