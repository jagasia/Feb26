import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class Main3 {

	public static void main(String[] args) {
		LinkedHashMap<String, String> cc=new LinkedHashMap<>();
		cc.put("INR","Bharath");
		cc.put("USD","United States of America");
		cc.put("AED","United Arab Emirates Dirham");
		cc.put("AFN","Afghanistan Afghani");
		cc.put("INR", "India");		//not adding. but updating
		cc.put("ALL","Albania Lek");
		cc.put("AMD","Armenia Dram");
		for(Entry<String, String> entry:cc.entrySet())
		{
			System.out.println(entry.getKey()+"\t:\t"+entry.getValue());
		}
	}

}
