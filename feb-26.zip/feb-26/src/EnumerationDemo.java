
class Car
{
	String name="Swift";
	String color;
	Engine engine=new Engine();
	
	class Engine
	{
		//this is inner class
		String neuralSchema="secret";
		public void start()
		{
			System.out.println(name+"......Grrrrrr.....");
		}
	}
	
	public void run() {
		System.out.println("Car is running in "+engine.neuralSchema);
	}
}

enum Days
{
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
};

public class EnumerationDemo {

	public static void main(String[] args) {
		Days today=Days.FRIDAY;
//		today=Days.FEBRUARY;			Not allowed. Only those 7 values are allowed
		System.out.println(today);
		
		Car swift=new Car();
		swift.engine.start();
		swift.run();
	}

}
