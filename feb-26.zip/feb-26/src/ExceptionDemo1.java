import java.io.IOException;

class InvalidAmountException extends Exception
{
	public InvalidAmountException(String message)
	{
		super(message);
	}
}

class Bank
{
	public void withdraw(int amount) throws InvalidAmountException 
	{
		if(amount>30000)
			throw new InvalidAmountException("Amount cannot be greater than 30000");
			//			System.out.println("Amount cannot be > 30k");
		else
			System.out.println("Remember to collect cash");
	}
}

public class ExceptionDemo1 {

	public static void main(String[] args) throws InvalidAmountException  {
		Bank sbi=new Bank();
		try {
			sbi.withdraw(34000);
		} catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		}finally
		{
			System.out.println("This is finally");
		}
		System.out.println("Continue...");
	}

}
